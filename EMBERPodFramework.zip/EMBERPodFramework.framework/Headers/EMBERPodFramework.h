//
//  EMBERPodFramework.h
//  EMBERPodFramework
//
//  Created by Enas Ahmed Zaki on 2/2/21.
//

#import <Foundation/Foundation.h>

//! Project version number for EMBERPodFramework.
FOUNDATION_EXPORT double EMBERPodFrameworkVersionNumber;

//! Project version string for EMBERPodFramework.
FOUNDATION_EXPORT const unsigned char EMBERPodFrameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <EMBERPodFramework/PublicHeader.h>


